module huffman {
    requires java.desktop;
}